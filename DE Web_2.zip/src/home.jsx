import React from 'react'
import Slider from './Carousel'

export default function Home() {
  return (
    <>
        <div>
        <marquee className="text-danger">Last date of the Team Registration is extended till 14-04-2023</marquee>
        </div>
        <Slider/>
    </>
  )
}
